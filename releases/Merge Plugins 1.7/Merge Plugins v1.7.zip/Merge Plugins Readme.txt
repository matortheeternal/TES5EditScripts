//==========================================================
|  Merge Plugins TES5Edit Script
|  Created by matortheeternal 
|  http://skyrim.nexusmods.com/mods/37981  
|
\\==========================================================



//=======Installation=======================================
Copy the contents of the included Edit Scripts folder into 
TES5Edit's Edit Scripts folder.  TES5Edit's Edit Scripts 
folder should be in the same directory as TES5Edit.exe.

If you don't have TES5Edit you can get the most recent
public release here: 
http://skyrim.nexusmods.com/mods/25859

As of 09/28/2014, TES5Edit 3.0.33 is still in beta.  This
version of TES5Edit has a lot of major updates that make
merging work better.  I highly recommend you get TES5Edit
3.0.33 if it still hasn't been publicly released.  You can
get the 3.0.33 beta here:
http://afkmods.iguanadons.net/index.php?/topic/3750-wipz-tes5edit/

If you're starting TES5Edit from a shortcut, make sure 
the shortcut points to the TES5Edit.exe located alongside 
the Edit Scripts folder where you installed the scripts!

For additional information and questions please see the 
Nexus Mods page at the url below:
http://skyrim.nexusmods.com/mods/37981
